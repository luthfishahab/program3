package program3;

public class Program3 {

    public static void main(String[] args) {
        String file[] = {
            //nama file             //index
            "1.burma14.tsp.txt",    //0
            "2.ulysses16.tsp.txt",  //1
            "3.gr17.tsp.txt",       //2
            "4.gr21.tsp.txt",       //3
            "5.ulysses22.tsp.txt",  //4
            "6.gr24.tsp.txt",       //5
            "7.fri26.tsp.txt",      //6
            "8.bayg29.tsp.txt",     //7
            "9.bays29.tsp.txt",     //8
            "10.dantzig42.tsp.txt", //9
            "11.swiss42.tsp.txt",   //10
            "12.att48.tsp.txt",     //11
            "13.gr48.tsp.txt",      //12
            "14.hk48.tsp.txt",      //13
            "15.eil51.tsp.txt",     //14
            "16.berlin52.tsp.txt",  //15
            "17.brazil58.tsp.txt",  //16
            "18.st70.tsp.txt",      //17
            "19.eil76.tsp.txt",     //18
            "20.pr76.tsp.txt",      //19
            "21.gr96.tsp.txt",      //20
            "22.rat99.tsp.txt",     //21
            "23.kroA100.tsp.txt",   //22
            "24.kroB100.tsp.txt",   //23
            "25.kroC100.tsp.txt",   //24
            "26.kroD100.tsp.txt",   //25
            "27.kroE100.tsp.txt",   //26
            "28.rd100.tsp.txt",     //27
            "29.eil101.tsp.txt",    //28
            "30.lin105.tsp.txt",    //29
            "31.pr107.tsp.txt",     //30
            "32.gr120.tsp.txt",     //31
            "33.pr124.tsp.txt",     //32
            "34.bier127.tsp.txt",   //33
            "35.ch130.tsp.txt",     //34
            "36.pr136.tsp.txt",     //35
            "37.gr137.tsp.txt",     //36
            "38.pr144.tsp.txt",     //37
            "39.ch150.tsp.txt",     //38
            "40.kroA150.tsp.txt",   //39
            "41.kroB150.tsp.txt",   //40
            "42.pr152.tsp.txt",     //41
            "43.u159.tsp.txt",      //42
            "44.si175.tsp.txt",     //43
            "45.brg180.tsp.txt",    //44
            "46.rat195.tsp.txt",    //45
            "47.d198.tsp.txt",      //46
            "48.kroA200.tsp.txt",   //47
            "49.kroB200.tsp.txt",   //48
            "50.gr202.tsp.txt"      //49
        };
        
        //pilih index
        int index = 0;
        
        String path = "D:\\2c. Data\\1. TSP\\1. Symmetric TSP\\3. Data Full Matrix\\" + file[index];
        Library.LoadD(path);
        
        int number_of_populations = 100;
        int number_of_iteration = 1000;
        
        Population pop = new Population(number_of_populations, true);
        
        for(int i = 0; i < number_of_iteration; i++) {
            pop = GA.evolvePopulation(pop);
        }
        
        System.out.println(file[index]);
        pop.getFittest().Print();
        pop.getFittest().PrintDistance();
    }
}