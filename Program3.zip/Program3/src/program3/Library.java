package program3;

public class Library {
    public static int n; //number of nodes
    public static int d[][]; //distance matrix
    
    public static void LoadD(String path) {
        java.io.File file = new java.io.File(path);
        
        try (java.util.Scanner input = new java.util.Scanner(file);) {
            n = input.nextInt();
            d = new int[n][n];
            for(int i = 0; i < n; i++) {
                for(int j = 0; j < n; j++) {
                    d[i][j] = input.nextInt();
                }
            }
        }
        catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }
    
    public static int[] RandomPermutation(int n) {
        int int1[] = new int[n];
        for(int i = 0; i < n; i++){
            int1[i] = i;
        }
        
        //generate random permutation
        int permutation[] = new int[n];
        for(int i = 0; i < n; i++){
            int j = (int)(Math.random()*(n-i));
            permutation[i] = int1[j];
            int1[j] = int1[n-i-1];
        }
        
        return permutation;
    }
    
    public static int GetDistance(int[] a) {
        int n = a.length;
        int result = 0;
        for(int i = 1; i < n; i++) {
            result += d[a[i-1]][a[i]];
        }
        result += d[a[n-1]][a[0]];
        return result;
    }
    
    public static Solution HKATerbatas1Solusi(Solution s, int max_iteration) {
        int result[] = s.getSolution();
        int skor_lama = s.getDistance();
        
        for(int i = 0; i < max_iteration; i++) {
            if(s.bisaHKATerbatas == 1) {
                int a[] = HKATerbatas1SolusiDari2SampaiNPer2(result, skor_lama);

                Putar(result, a[0], a[1]);

                int skor_baru = a[2];

                if(skor_baru != skor_lama) {
                    skor_lama = skor_baru;
                    s.setSolution(result);
                    s.setDistance(skor_lama);
                }
                else {
                    s.bisaHKATerbatas = 0;
                }
            }
            else {
                break;
            }
        }
        
        return s;
    }
    
    public static int[] HKATerbatas1SolusiDari2SampaiNPer2(int a[], int score_a) {
        int N = a.length/2;
        int index[] = new int[N-1];
        int score[] = new int[N-1];

        // mencari index terbaik jika subsolusi sepanjang i di reverse
        for(int i = 2; i <= N; i++) {
            int hasil[] = PutarBNodeDariA(a, i);

            index[i-2] = hasil[0];
            //int b[] = a.clone();
            //Putar(b, index[i-2], i);
            //score[i-2] = Score(b);

            /*
            // i adalah index dan b adalah panjang
            int A = a[(index[i-2]-1 + a.length) % a.length];
            int B = a[index[i-2]];
            int C = a[(index[i-2]+i-1) % a.length];
            int D = a[(index[i-2]+i) % a.length];
            */
            score[i-2] = score_a + hasil[1];
        }

        int index_of_min = IndexOfMin(score);

        int result[] = {index[index_of_min], index_of_min+2, score[index_of_min]};

        return result;
    }
    
    public static void Putar(int a[], int p, int n) {
        for(int i = 0; i < n/2; i++) {
            int b = (p+i)%a.length;
            int c = (p+n-i-1)%a.length;
            int dummy = a[b];
            a[b] = a[c];
            a[c] = dummy;
        }
    }
    
    // sub-solusi sepanjang b dari a[] di reverse urutannya. 
    public static int[] PutarBNodeDariA(int a[], int b) {
        int score[] = new int[a.length];
        for(int i = 0; i < a.length; i++) {
            //                  i    i+1  i+2
            // diputar menjadi  i+2  i+1  i

            // index    A    B         C    D
            // sehingga i-1  i    i+1  i+2  i+3
            // menjadi  i-1  i+2  i+1  i    i+3

            int A = a[(i-1+a.length)%a.length];
            int B = a[i];
            int C = a[(i+b-1)%a.length];
            int D = a[(i+b)%a.length];

            score[i] = -d[A][B] - d[C][D] + d[A][C] + d[B][D];
        }
        int index_of_min = IndexOfMin(score);

        // yang dikembalikan adalah index dimana ia optimal, dan score dari perputaran index itu
        int result[] = {index_of_min, score[index_of_min]};

        return result;
    }
    
    public static int IndexOfMin(int a[]) {
        int index = 0;
        double min = a[0];
        for(int i = 1; i < a.length; i++) {
            if(min > a[i]) {
                min = a[i];
                index = i;
            }
        }
        return index;
    }
}