package program3;

public class GA {
    // Evolves a population over one generation
    public static Population evolvePopulation(Population pop) {
        int a = 2*pop.populationSize();
        int b = pop.populationSize();

        Population newPopulation = new Population(b, false);

        for (int i = 0; i < b; i++) {
            Solution child = new Solution(pop.getSolution(i).getSolution(), pop.getSolution(i).getDistance());
            mutate(child);
            newPopulation.saveSolution(i, child);
        }

        Population newPopulation2 = new Population(a, false);

        for (int i = 0; i < pop.populationSize(); i++) {
            newPopulation2.saveSolution(i, pop.getSolution(i));
        }

        for (int i = 0; i < pop.populationSize(); i++) {
            newPopulation2.saveSolution((b+i), newPopulation.getSolution(i));
        }
        
        // masih bisa dipercepat dengan metode sort yang lebih baik
        for (int i = 0; i < a; i++){
            int k = i;
            Solution fittest = newPopulation2.getSolution(i);

            for (int j = i+1; j < a; j++) {
                if (newPopulation2.getSolution(j).getDistance() < fittest.getDistance()) {
                    fittest = newPopulation2.getSolution(j);
                    k = j;
                }
            }

            newPopulation2.saveSolution(k, newPopulation2.getSolution(i));
            newPopulation2.saveSolution(i, fittest);
        }
        
        Population newPopulation3 = new Population(b, false);
        
        int m = 0;
        newPopulation3.saveSolution(0, newPopulation2.getSolution(0));

        for (int i = 1; i < b; i++){
            if (newPopulation2.getSolution(i).getDistance() != newPopulation3.getSolution(m).getDistance()){
                m++;
                newPopulation3.saveSolution(m, newPopulation2.getSolution(i));
            }
        }

        if ((m+1) != b){
            for (int i = m+1; i < b; i++){
                int ran = (int) (Math.random() * a);
                newPopulation3.saveSolution(i, newPopulation2.getSolution(ran));
            }
        }

        evolvePopulationWithHKABaru(newPopulation3);
        
        return newPopulation3;
    }
    
    public static void evolvePopulationWithHKABaru(Population pop) {
        int max = 1;
        for(int i = 0; i < pop.populationSize(); i++) {
            Solution b = Library.HKATerbatas1Solusi(pop.getSolution(i), max);
            pop.saveSolution(i, b);
        }
    }
    
    // Mutate a tour using swap mutation
    private static void mutate(Solution tour) {
        tour.mutate();
    }
}